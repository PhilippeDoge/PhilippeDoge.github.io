<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Votre profil</title>
	<link href="style.css" rel="stylesheet">
</head>
<body>
	<h1>Votre profil</h1>
	<?php
		require_once "connect.php";
		$pseudo=$_GET['pseudo'];
		echo "<a href=\"accueil.php?pseudo=".$pseudo."\">Retour en arrière</a>";

		//Récupère les données
		$getinfo="SELECT * FROM profil WHERE pseudo='$pseudo';";
		$data=mysqli_query($conn,$getinfo);
		$row=mysqli_fetch_assoc($data);
		$followers=$row['followers'];
		$publications=$row['publications'];
		$admin=$row['admin'];

	?>

	<form method="POST" action="">

		<p>Pseudo:<?php echo "$pseudo";?></p>
		<p>Followers:<?php echo "$followers";?></p>
		<p>Publications:<?php echo "$publications";?></p>
		<p>Admin:<?php if($admin==0){echo "Non";}else{echo "Oui";};?></p>

		<input type="submit" name="mdp" value="Changer le mot de passe"> 
	</form>
	<?php

		if(isset($_POST['mdp'])){
			header("Location:modif mdp.php?pseudo=$pseudo");
			exit;
		}

		?>




</body>
</html>